//package Main;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

public class User extends Login implements Withdraw, Deposit, Pin_Change, Change_Details, Check_Balance, Show_Details, Imp_Functions
{

}
